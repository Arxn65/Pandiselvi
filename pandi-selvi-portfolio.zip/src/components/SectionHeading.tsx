export function SectionHeading({ title, subtitle }: { title: string; subtitle?: string }) {
  return (
    <div className="text-center mb-12 animate-fade-up">
      <h2 className="text-3xl md:text-4xl font-bold font-[family-name:var(--font-heading)]">
        <span className="glow-text">{title}</span>
      </h2>
      {subtitle && (
        <p className="mt-3 text-muted-foreground max-w-xl mx-auto">{subtitle}</p>
      )}
    </div>
  );
}
