import { createFileRoute } from "@tanstack/react-router";
import { SectionHeading } from "@/components/SectionHeading";
import { GraduationCap, Briefcase } from "lucide-react";

export const Route = createFileRoute("/about")({
  head: () => ({
    meta: [
      { title: "About — Pandi Selvi M" },
      { name: "description", content: "Learn about Pandi Selvi M, a passionate Civil Engineering student focused on sustainable infrastructure." },
    ],
  }),
  component: AboutPage,
});

function AboutPage() {
  return (
    <section className="section-padding">
      <div className="mx-auto max-w-6xl">
        <SectionHeading title="About Me" subtitle="Passionate about building a better world" />

        <div className="glass-card p-8 mb-12 animate-fade-up animate-delay-100">
          <p className="text-foreground/90 leading-relaxed text-lg">
            I am Pandi Selvi M, a passionate Civil Engineering student with a strong focus on sustainable and eco-friendly infrastructure. I have hands-on experience in structural design, site supervision, and drafting using AutoCAD. I am deeply interested in creating energy-efficient and innovative construction solutions. With a quick learning mindset, strong teamwork skills, and a commitment to excellence, I aim to contribute to impactful engineering projects and grow as a professional in the construction industry.
          </p>
        </div>

        <div className="grid md:grid-cols-2 gap-8">
          {/* Education */}
          <div className="animate-fade-up animate-delay-200">
            <h3 className="text-xl font-bold mb-6 flex items-center gap-2 text-primary">
              <GraduationCap size={22} /> Education
            </h3>
            <div className="space-y-4">
              {[
                { title: "B.E Civil Engineering", place: "Sethu Institute of Technology", year: "2022–2026", score: "CGPA: 8.4" },
                { title: "HSC", place: "Govt. Girls Higher Secondary School", year: "2021–2022", score: "63%" },
                { title: "SSLC", place: "Govt. Girls Higher Secondary School", year: "2019–2020", score: "70%" },
              ].map((edu) => (
                <div key={edu.title} className="glass-card p-5 hover-lift">
                  <h4 className="font-semibold text-foreground">{edu.title}</h4>
                  <p className="text-sm text-muted-foreground mt-1">{edu.place}</p>
                  <div className="flex justify-between mt-2 text-sm">
                    <span className="text-primary">{edu.year}</span>
                    <span className="text-accent">{edu.score}</span>
                  </div>
                </div>
              ))}
            </div>
          </div>

          {/* Experience */}
          <div className="animate-fade-up animate-delay-300">
            <h3 className="text-xl font-bold mb-6 flex items-center gap-2 text-primary">
              <Briefcase size={22} /> Experience
            </h3>
            <div className="space-y-4">
              <div className="glass-card p-5 hover-lift">
                <h4 className="font-semibold text-foreground">Tamil Nadu Highway Department</h4>
                <p className="text-sm text-primary mt-1">Intern — 15 days</p>
                <ul className="mt-3 space-y-1 text-sm text-muted-foreground list-disc list-inside">
                  <li>Monitored construction progress</li>
                  <li>Coordinated with engineers and contractors</li>
                  <li>Ensured safety and quality standards</li>
                </ul>
              </div>
              <div className="glass-card p-5 hover-lift">
                <h4 className="font-semibold text-foreground">DreamCarve, Madurai</h4>
                <p className="text-sm text-primary mt-1">Intern — 15 days</p>
                <ul className="mt-3 space-y-1 text-sm text-muted-foreground list-disc list-inside">
                  <li>Prepared AutoCAD 2D drawings and floor plans</li>
                  <li>Assisted in building layouts</li>
                  <li>Understood structural drawings and execution</li>
                </ul>
              </div>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
}
