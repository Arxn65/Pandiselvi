import { createFileRoute } from "@tanstack/react-router";
import { SectionHeading } from "@/components/SectionHeading";
import { Leaf, Thermometer } from "lucide-react";

export const Route = createFileRoute("/projects")({
  head: () => ({
    meta: [
      { title: "Projects — Pandi Selvi M" },
      { name: "description", content: "Civil engineering projects by Pandi Selvi M focusing on sustainability and innovation." },
    ],
  }),
  component: ProjectsPage,
});

const projects = [
  {
    icon: Leaf,
    title: "Reusage of C & D Waste as Green Roof",
    description: "Focused on sustainable construction by reusing construction and demolition waste. Promoted eco-friendly building practices and waste reduction.",
    tags: ["Sustainability", "Green Building", "Waste Management"],
  },
  {
    icon: Thermometer,
    title: "Thermal Resistance Brick using Phase Change Material",
    description: "Designed innovative bricks to improve energy efficiency. Helps maintain indoor temperature stability using phase change materials.",
    tags: ["Energy Efficiency", "Innovation", "Materials"],
  },
];

function ProjectsPage() {
  return (
    <section className="section-padding">
      <div className="mx-auto max-w-6xl">
        <SectionHeading title="Projects" subtitle="Innovative solutions for modern challenges" />

        <div className="grid md:grid-cols-2 gap-8">
          {projects.map((project, i) => (
            <div
              key={project.title}
              className={`glass-card glow-border p-8 hover-lift animate-fade-up ${i === 0 ? "animate-delay-100" : "animate-delay-200"}`}
            >
              <div className="w-12 h-12 rounded-xl bg-primary/10 flex items-center justify-center mb-5">
                <project.icon size={24} className="text-primary" />
              </div>
              <h3 className="text-xl font-bold text-foreground mb-3">{project.title}</h3>
              <p className="text-muted-foreground leading-relaxed mb-5">{project.description}</p>
              <div className="flex flex-wrap gap-2">
                {project.tags.map((tag) => (
                  <span key={tag} className="text-xs px-3 py-1 rounded-full bg-primary/10 text-primary font-medium">{tag}</span>
                ))}
              </div>
            </div>
          ))}
        </div>
      </div>
    </section>
  );
}
