import { createFileRoute } from "@tanstack/react-router";
import { SectionHeading } from "@/components/SectionHeading";
import { Code, Users, Globe } from "lucide-react";

export const Route = createFileRoute("/skills")({
  head: () => ({
    meta: [
      { title: "Skills — Pandi Selvi M" },
      { name: "description", content: "Technical and soft skills of Pandi Selvi M in civil engineering." },
    ],
  }),
  component: SkillsPage,
});

const technicalSkills = [
  { name: "AutoCAD 2D", level: 85 },
  { name: "StaadPro", level: 70 },
  { name: "Structural Drafting", level: 80 },
  { name: "RCC Design & Steel Structures", level: 75 },
  { name: "Surveying & Levelling", level: 78 },
  { name: "MS Office", level: 90 },
];

const softSkills = ["Communication", "Leadership", "Time Management", "Quick Learning"];
const languages = ["Tamil", "English"];

function SkillsPage() {
  return (
    <section className="section-padding">
      <div className="mx-auto max-w-6xl">
        <SectionHeading title="My Skills" subtitle="Tools & abilities I bring to projects" />

        <div className="grid md:grid-cols-2 gap-10">
          {/* Technical */}
          <div className="animate-fade-up animate-delay-100">
            <h3 className="text-xl font-bold mb-6 flex items-center gap-2 text-primary">
              <Code size={22} /> Technical Skills
            </h3>
            <div className="space-y-5">
              {technicalSkills.map((skill) => (
                <div key={skill.name}>
                  <div className="flex justify-between mb-1.5 text-sm">
                    <span className="text-foreground font-medium">{skill.name}</span>
                    <span className="text-primary">{skill.level}%</span>
                  </div>
                  <div className="skill-bar">
                    <div className="skill-bar-fill" style={{ width: `${skill.level}%` }} />
                  </div>
                </div>
              ))}
            </div>
          </div>

          <div className="space-y-10">
            {/* Soft skills */}
            <div className="animate-fade-up animate-delay-200">
              <h3 className="text-xl font-bold mb-6 flex items-center gap-2 text-primary">
                <Users size={22} /> Soft Skills
              </h3>
              <div className="flex flex-wrap gap-3">
                {softSkills.map((s) => (
                  <span key={s} className="glass-card px-4 py-2 text-sm font-medium text-foreground hover-lift cursor-default">{s}</span>
                ))}
              </div>
            </div>

            {/* Languages */}
            <div className="animate-fade-up animate-delay-300">
              <h3 className="text-xl font-bold mb-6 flex items-center gap-2 text-primary">
                <Globe size={22} /> Languages
              </h3>
              <div className="flex flex-wrap gap-3">
                {languages.map((l) => (
                  <span key={l} className="glass-card px-4 py-2 text-sm font-medium text-foreground hover-lift cursor-default">{l}</span>
                ))}
              </div>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
}
