import { createFileRoute, Link } from "@tanstack/react-router";
import { ArrowDown, Download, Mail } from "lucide-react";
import heroBg from "@/assets/hero-bg.jpg";
import profileImg from "@/assets/profile.png";

export const Route = createFileRoute("/")({
  component: HomePage,
});

function HomePage() {
  return (
    <section className="relative min-h-screen flex items-center justify-center overflow-hidden">
      {/* Background */}
      <div className="absolute inset-0">
        <img src={heroBg} alt="" className="w-full h-full object-cover" width={1920} height={1080} />
        <div className="absolute inset-0 bg-background/60" />
      </div>

      <div className="relative z-10 mx-auto max-w-6xl px-6 py-20 flex flex-col lg:flex-row items-center gap-12">
        {/* Text */}
        <div className="flex-1 text-center lg:text-left">
          <p className="text-primary font-medium mb-3 animate-fade-up">Hello, I'm</p>
          <h1 className="text-4xl md:text-6xl font-extrabold font-[family-name:var(--font-heading)] leading-tight animate-fade-up animate-delay-100">
            <span className="glow-text">Pandi Selvi M</span>
          </h1>
          <p className="mt-2 text-xl md:text-2xl text-foreground/80 font-medium animate-fade-up animate-delay-200">
            Civil Engineering Student
          </p>
          <p className="mt-4 text-muted-foreground max-w-lg mx-auto lg:mx-0 animate-fade-up animate-delay-300">
            "Building Sustainable and Innovative Infrastructure for the Future"
          </p>

          <div className="mt-8 flex flex-wrap gap-4 justify-center lg:justify-start animate-fade-up animate-delay-400">
            <Link to="/contact" className="glow-button inline-flex items-center gap-2">
              <Mail size={16} /> Hire Me
            </Link>
            <a href="#" className="outline-glow-button inline-flex items-center gap-2">
              <Download size={16} /> Download Resume
            </a>
            <Link to="/contact" className="outline-glow-button inline-flex items-center gap-2">
              Contact Me
            </Link>
          </div>
        </div>

        {/* Profile image */}
        <div className="flex-shrink-0 animate-fade-up animate-delay-200">
          <div className="relative w-64 h-64 md:w-80 md:h-80 rounded-full overflow-hidden glow-border" style={{ animation: "pulse-glow 3s ease-in-out infinite" }}>
            <img src={profileImg} alt="Pandi Selvi M" className="w-full h-full object-cover" width={512} height={512} />
          </div>
        </div>
      </div>

      {/* Scroll indicator */}
      <div className="absolute bottom-8 left-1/2 -translate-x-1/2 text-muted-foreground" style={{ animation: "float 2s ease-in-out infinite" }}>
        <ArrowDown size={24} />
      </div>
    </section>
  );
}
