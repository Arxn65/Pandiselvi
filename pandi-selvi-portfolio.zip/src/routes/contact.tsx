import { createFileRoute } from "@tanstack/react-router";
import { SectionHeading } from "@/components/SectionHeading";
import { Mail, Phone, MapPin } from "lucide-react";

export const Route = createFileRoute("/contact")({
  head: () => ({
    meta: [
      { title: "Contact — Pandi Selvi M" },
      { name: "description", content: "Get in touch with Pandi Selvi M for civil engineering collaborations." },
    ],
  }),
  component: ContactPage,
});

function LinkedInIcon({ size = 20 }: { size?: number }) {
  return (
    <svg width={size} height={size} viewBox="0 0 24 24" fill="currentColor">
      <path d="M20.447 20.452h-3.554v-5.569c0-1.328-.027-3.037-1.852-3.037-1.853 0-2.136 1.445-2.136 2.939v5.667H9.351V9h3.414v1.561h.046c.477-.9 1.637-1.85 3.37-1.85 3.601 0 4.267 2.37 4.267 5.455v6.286zM5.337 7.433a2.062 2.062 0 01-2.063-2.065 2.064 2.064 0 112.063 2.065zm1.782 13.019H3.555V9h3.564v11.452zM22.225 0H1.771C.792 0 0 .774 0 1.729v20.542C0 23.227.792 24 1.771 24h20.451C23.2 24 24 23.227 24 22.271V1.729C24 .774 23.2 0 22.222 0h.003z" />
    </svg>
  );
}

function ContactPage() {
  return (
    <section className="section-padding">
      <div className="mx-auto max-w-4xl">
        <SectionHeading title="Contact Me" subtitle="Let's build something amazing together" />

        <div className="grid sm:grid-cols-2 gap-6 mb-10">
          {[
            { icon: Mail, label: "Email", value: "pandiselvimayavu@gmail.com", href: "mailto:pandiselvimayavu@gmail.com" },
            { icon: Phone, label: "Phone", value: "+91 6383859334", href: "tel:+916383859334" },
          ].map((item) => (
            <a key={item.label} href={item.href} className="glass-card p-6 hover-lift flex items-start gap-4 animate-fade-up">
              <div className="w-10 h-10 rounded-lg bg-primary/10 flex items-center justify-center flex-shrink-0">
                <item.icon size={20} className="text-primary" />
              </div>
              <div>
                <p className="text-sm text-muted-foreground">{item.label}</p>
                <p className="text-foreground font-medium mt-1">{item.value}</p>
              </div>
            </a>
          ))}
        </div>

        <a
          href="https://www.linkedin.com/in/pandiselvi-mayavu-0986b32b9"
          target="_blank"
          rel="noopener noreferrer"
          className="glass-card p-6 hover-lift flex items-center gap-4 animate-fade-up animate-delay-200 max-w-sm mx-auto"
        >
          <div className="w-10 h-10 rounded-lg bg-primary/10 flex items-center justify-center flex-shrink-0 text-primary">
            <LinkedInIcon size={20} />
          </div>
          <div>
            <p className="text-sm text-muted-foreground">LinkedIn</p>
            <p className="text-foreground font-medium mt-1">Pandi Selvi M</p>
          </div>
        </a>
      </div>
    </section>
  );
}
