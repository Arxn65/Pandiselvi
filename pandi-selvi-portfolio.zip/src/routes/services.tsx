import { createFileRoute } from "@tanstack/react-router";
import { SectionHeading } from "@/components/SectionHeading";
import { PenTool, Building2, HardHat, Leaf, BarChart3 } from "lucide-react";

export const Route = createFileRoute("/services")({
  head: () => ({
    meta: [
      { title: "Services — Pandi Selvi M" },
      { name: "description", content: "Civil engineering services offered by Pandi Selvi M." },
    ],
  }),
  component: ServicesPage,
});

const services = [
  { icon: PenTool, title: "Structural Drafting using AutoCAD", desc: "Precise 2D drafting and floor plan preparation for residential and commercial projects." },
  { icon: Building2, title: "Building Planning & Design", desc: "Comprehensive building layout planning with focus on functionality and aesthetics." },
  { icon: HardHat, title: "Site Supervision Assistance", desc: "On-site monitoring to ensure quality standards and construction progress." },
  { icon: Leaf, title: "Sustainable Construction Solutions", desc: "Eco-friendly building strategies using recycled materials and energy-efficient designs." },
  { icon: BarChart3, title: "Basic Structural Analysis Support", desc: "Structural load analysis and design verification for small to mid-scale projects." },
];

function ServicesPage() {
  return (
    <section className="section-padding">
      <div className="mx-auto max-w-6xl">
        <SectionHeading title="Services" subtitle="What I can do for you" />

        <div className="grid sm:grid-cols-2 lg:grid-cols-3 gap-6">
          {services.map((service, i) => (
            <div
              key={service.title}
              className={`glass-card p-6 hover-lift animate-fade-up`}
              style={{ animationDelay: `${(i + 1) * 0.1}s` }}
            >
              <div className="w-11 h-11 rounded-lg bg-primary/10 flex items-center justify-center mb-4">
                <service.icon size={22} className="text-primary" />
              </div>
              <h3 className="font-bold text-foreground mb-2">{service.title}</h3>
              <p className="text-sm text-muted-foreground leading-relaxed">{service.desc}</p>
            </div>
          ))}
        </div>
      </div>
    </section>
  );
}
